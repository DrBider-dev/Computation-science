package Control;

public class Launcher {
    public static void main(String[] args) {
        new ControlFachada();
    }   
}
